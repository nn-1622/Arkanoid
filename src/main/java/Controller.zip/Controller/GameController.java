package Controller;

import Model.GameModel;
import Model.GameplayModel;
import Model.State;
import View.GameView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;


/**
 * Lớp điều khiển chính của trò chơi.
 * Lớp này chịu trách nhiệm xử lý các đầu vào từ người dùng (bàn phím, chuột),
 * cập nhật trạng thái của trò chơi (Model) và yêu cầu View vẽ lại giao diện.
 * Nó cũng hoạt động như một GameEventListener để xử lý các sự kiện từ GameplayModel.
 */
public class GameController implements GameEventListener {
    private GameModel model;
    private GameView view;
    private MouseEvent e;
    private boolean leftpressed;
    private boolean rightpressed;
    private long lastUpdateTime = 0;
    // Bổ sung cho chế độ 2 người chơi
    private boolean left2pressed;
    private boolean right2pressed;

    private static final double FADE_DURATION = 2.0;

    private double leftFadeStart = -1;
    private double rightFadeStart = -1;


    /**
     * Khởi tạo một GameController mới với GameModel và GameView được cung cấp.
     * @param gm Model của trò chơi, chứa dữ liệu và trạng thái game.
     * @param gv View của trò chơi, chịu trách nhiệm hiển thị.
     */
    public GameController(GameModel gm, GameView gv, SoundManager soundManager) {
        this.model = gm;
        this.view = gv;
        setInput();
        gm.getEventLoader().register(this);
        gm.getEventLoader().register(soundManager);
    }

    @Override
    public void onGameEvent (GameEvent event) {
        switch (event) {
            case GAME_WIN:
                model.setGstate(State.VICTORY);
                break;
            case GAME_LOST:
                model.setGstate(State.LOSS);
                break;
            case LEVEL_COMPLETE:
                model.setFadeStartTime(System.nanoTime());
                model.setGstate(State.FADE);
                break;
        }
    }

    /**
     * Phương thức cập nhật chính của trò chơi, được gọi liên tục bởi AnimationTimer.
     * Phương thức này tính toán delta time, yêu cầu view vẽ lại trạng thái hiện tại của model,
     * và cập nhật logic của game dựa trên trạng thái (PLAYING, FADE, v.v.).
     * @param now Thời gian hệ thống hiện tại tính bằng nano giây.
     */
    public void update(long now) {
        if (lastUpdateTime == 0) {
            lastUpdateTime = now;
        }

        long elapsed = now - lastUpdateTime;
        double deltaTime = elapsed / 1_000_000_000.0;
        lastUpdateTime = now;

        view.render(model);

        // ----- SINGLE PLAYER -----
        if (model.getGstate() == State.PLAYING) {
            this.model.getGameplayModel().update(leftpressed, rightpressed, deltaTime);
        }

        // ----- TWO PLAYER MODE -----
        else if (model.getGstate() == State.TWO_PLAYING) {
            GameplayModel leftGame = model.getLeftGame();
            GameplayModel rightGame = model.getRightGame();
            if (leftGame == null || rightGame == null) return;

            boolean leftDead = leftGame.getLives() <= 0;
            boolean rightDead = rightGame.getLives() <= 0;
            boolean leftDoneAll = leftGame.hasCompletedAllLevels();
            boolean rightDoneAll = rightGame.hasCompletedAllLevels();
            boolean leftFinished = leftGame.isLevelFinished() || leftDoneAll;
            boolean rightFinished = rightGame.isLevelFinished() || rightDoneAll;
            boolean bothDead = leftDead && rightDead;
            boolean bothDone = leftDoneAll && rightDoneAll;

            // ----- KHI CẢ HAI ĐÃ CHẾT HOẶC ĐÃ HOÀN THÀNH TOÀN BỘ -----
            if (bothDead || bothDone) {
                int leftScore = leftGame.getScore();
                int rightScore = rightGame.getScore();

                // Bắt đầu đếm thời gian hiển thị kết quả
                model.startResultTimer();

                if (leftScore > rightScore) {
                    leftGame.setWinner(true);
                    rightGame.setLoser(true);
                } else if (rightScore > leftScore) {
                    rightGame.setWinner(true);
                    leftGame.setLoser(true);
                } else {
                    leftGame.setDraw(true);
                    rightGame.setDraw(true);
                }

                // Tắt trạng thái chờ
                leftGame.setWaitingForOtherPlayer(false);
                rightGame.setWaitingForOtherPlayer(false);

                // Sau 5 giây hoặc khi người chơi nhấn phím → quay lại menu
                if (model.hasResultTimeElapsed(5000)) {
                    model.setGstate(State.MENU);
                }
                return;
            }

            // ----- CẬP NHẬT LOGIC CHỜ -----
            boolean leftShouldWait = (leftFinished || leftDead) && !(rightFinished || rightDead);
            boolean rightShouldWait = (rightFinished || rightDead) && !(leftFinished || leftDead);
            leftGame.setWaitingForOtherPlayer(leftShouldWait);
            rightGame.setWaitingForOtherPlayer(rightShouldWait);

            // ----- UPDATE BÊN NÀO CÒN ĐANG CHƠI -----
            if (!leftDead && !leftDoneAll && !leftGame.isLevelFinished()) {
                leftGame.update(leftpressed, rightpressed, deltaTime);
            }
            if (!rightDead && !rightDoneAll && !rightGame.isLevelFinished()) {
                rightGame.update(left2pressed, right2pressed, deltaTime);
            }

            // ----- CẢ HAI CÙNG HOÀN THÀNH MÀN -----
            if (leftFinished && rightFinished) {
                if (!leftGame.isFading())  leftGame.startFade(now);
                if (!rightGame.isFading()) rightGame.startFade(now);

                double leftElapsed = (now - leftGame.getFadeStartTime()) / 1_000_000_000.0;
                double rightElapsed = (now - rightGame.getFadeStartTime()) / 1_000_000_000.0;

                if (leftElapsed >= FADE_DURATION && rightElapsed >= FADE_DURATION) {
                    // Reset fade và trạng thái hoàn thành
                    leftGame.setLevelFinished(false);
                    rightGame.setLevelFinished(false);
                    leftGame.stopFade();
                    rightGame.stopFade();

                    // Qua level mới (nếu còn)
                    if (!leftDoneAll) leftGame.Initialize();
                    if (!rightDoneAll) rightGame.Initialize();

                    // Nếu cả hai đã xong toàn bộ → VICTORY chung
                    if (leftGame.hasCompletedAllLevels() && rightGame.hasCompletedAllLevels()) {
                        leftGame.setWinner(true);
                        rightGame.setWinner(true);
                        model.setGstate(State.VICTORY);
                        return;
                    }
                }
            }
        }

        // ----- FADE SINGLE PLAYER -----
        else if (model.getGstate() == State.FADE) {
            double timeElapsed = (now - model.getFadeStartTime()) / 1_000_000_000.0;
            if (timeElapsed >= FADE_DURATION) {
                if (model.getGameplayModel() != null) {
                    model.getGameplayModel().Initialize();
                    model.setGstate(State.PLAYING);
                }
            }
        }
    }


    /**
     * Thiết lập các trình xử lý sự kiện cho đầu vào từ chuột và bàn phím.
     * Các sự kiện này điều khiển các hành động khác nhau tùy thuộc vào trạng thái hiện tại của trò chơi
     * (ví dụ: điều hướng menu, di chuyển thanh trượt, phóng bóng).
     */
    public void setInput() {
        // Xử lý sự kiện di chuyển chuột để tạo hiệu ứng hover cho các nút
        view.getScene().setOnMouseMoved(e -> {
            if (model.getCurrentView() != null) {
                model.getCurrentView().checkHover(e);
            }
        });

        // Xử lý sự kiện nhấp chuột để tương tác với các nút trong các màn hình khác nhau
        view.getScene().setOnMouseClicked(e -> {
            if (model.getCurrentView() != null) {
                model.getCurrentView().handleClick(e);
            }
            if (model.getGstate() == State.VICTORY || model.getGstate() == State.LOSS) {
                model.setGstate(State.MENU);
                return;
            }

        });

        // Xử lý sự kiện nhấn phím
        view.getScene().setOnKeyPressed(e -> {
            if (model.getGstate() == State.VICTORY || model.getGstate() == State.LOSS) {
                if (e.getCode() == KeyCode.ENTER || e.getCode() == KeyCode.ESCAPE) {
                    model.setGstate(State.MENU);
                    return;
                }
            }
            switch (e.getCode()) {
                case A -> leftpressed = true; // Di chuyển sang trái
                case D -> rightpressed = true; // Di chuyển sang phải
                case LEFT -> left2pressed = true;   // Player 2 sang trái
                case RIGHT -> right2pressed = true; // Player 2 sang phải
                case SPACE -> {
                    if (model.getGstate() == State.TWO_PLAYING) {
                        if (model.getLeftGame() != null)
                            model.getLeftGame().launchBall(); // P1 bắn bóng
                    } else {
                        model.getGameplayModel().launchBall();
                    }
                }
                case ENTER -> {
                    if (model.getGstate() == State.TWO_PLAYING && model.getRightGame() != null)
                        model.getRightGame().launchBall(); // P2 bắn bóng
                }
            }
        });

        // Xử lý sự kiện nhả phím
        view.getScene().setOnKeyReleased(e -> {
            switch (e.getCode()) {
                case A -> leftpressed = false; // Dừng di chuyển sang trái
                case D -> rightpressed = false; // Dừng di chuyển sang phải
                case LEFT -> left2pressed = false;
                case RIGHT -> right2pressed = false;
            }
        });
    }
}