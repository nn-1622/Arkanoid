package Controller;

public enum GameEvent {
    BALL_HIT,
    GAME_WIN,
    GAME_LOST,
    LEVEL_COMPLETE
}
