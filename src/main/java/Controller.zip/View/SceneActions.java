package View;

import javafx.scene.input.MouseEvent;

public interface SceneActions {
    public void checkHover(MouseEvent e);
    public void handleClick(MouseEvent e);
}
