package Controller;

public interface GameCommand {
    void execute();
}
